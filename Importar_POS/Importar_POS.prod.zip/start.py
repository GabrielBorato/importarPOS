from flask import Flask, render_template, request
import subprocess
from bot import operar_robo  # Importe a função operar_robo do bot.py

app = Flask(__name__)

# Rota para renderizar a página inicial
@app.route('/')
def index():
    return render_template('portal.html')

# Rota para processar o formulário quando enviado
@app.route('/operar-robo', methods=['POST'])
def operar_robo_flask():
    
    # Captura a data do formulário
    data_recebida = request.form['dataRecebida']

    # Chama a função operar_robo do bot.py com a data recebida
    resultado = operar_robo(data_recebida)

    # Inicia o bot.py somente após processar a data
    subprocess.Popen(["python", "bot.py"])

    # Retorna uma resposta para o cliente
    return "Robô financeiro está sendo operado, aguarde 15 minutos para a conclusão."

if __name__ == '__main__':
    app.run(debug=True)
