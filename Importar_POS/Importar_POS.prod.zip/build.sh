#!/bin/bash

zip -r "Importar_POS.prod.zip" * -x "Importar_POS.prod.zip"